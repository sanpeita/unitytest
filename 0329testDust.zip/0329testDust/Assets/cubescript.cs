﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[AddComponentMenu("TestEditor")]
public class cubescript : MonoBehaviour
{
    public float Rot_x;
    public float Rot_y;
    public float Rot_z;

    public int healthChange = -1;

    void Update()
    {
        transform.Rotate(Rot_x, Rot_y, Rot_z);
    }
}
