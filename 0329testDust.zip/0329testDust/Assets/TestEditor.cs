﻿using UnityEngine;
using UnityEditor;
using System.Collections;

[CanEditMultipleObjects]
[CustomEditor(typeof(cubescript))]
//public class TestEditor : InspectorBase
public class TestEditor : Editor
{
    public override void OnInspectorGUI()
    {
        //メモを表示
        EditorGUILayout.LabelField("ここにメモや注意事項を記載できます");
        //トグルを表示
        EditorGUILayout.Toggle("トグル", false);
        //スライダーを表示（引数は「初期値,最小値,最大値」）
        EditorGUILayout.IntSlider("スライダー", 100, 0, 200);
        //カラーを表示
        EditorGUILayout.ColorField("カラー", Color.white);
        //ポップアップを表示
        EditorGUILayout.IntPopup("ポップアップ", 1, new string[] { "小", "中", "大", }, new int[] { 0, 1, 2 });
        //XYZ座標を表示
        EditorGUILayout.Vector3IntField("XYZ座標", Vector3Int.one);
        //テキストフィールドを表示
        EditorGUILayout.TextField("テキストフィールド", "");
        //ヘルプボックスを表示 
        EditorGUILayout.HelpBox("ヘルプボックス", MessageType.Info);

        base.OnInspectorGUI();

        GUIStyle style = new GUIStyle(EditorStyles.label);

        /*
        if (serializedObject.FindProperty("healthChange").intValue < 0)
        {
            style.normal.textColor = Color.red;
            EditorGUILayout.LabelField("This object will damage on impact", style);
        }
        else if (serializedObject.FindProperty("healthChange").intValue > 0)
        {
            style.normal.textColor = Color.blue;
            EditorGUILayout.LabelField("This object will heal on impact", style);
        }
        else
        {
            EditorGUILayout.LabelField("This object will have no effect");
        }
        */





    }
}