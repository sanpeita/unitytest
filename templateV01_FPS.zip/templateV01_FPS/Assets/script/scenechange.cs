﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class scenechange : MonoBehaviour
{
    public void changer ()
    {
        Scene scene = SceneManager.GetActiveScene();
        if (scene.name == "GameStart")
        {
            SceneManager.LoadScene("GameMain");
        }
        if (scene.name == "GameMain")
        {
            SceneManager.LoadScene("GameEnd");
        }
        if (scene.name == "GameEnd")
        {
            SceneManager.LoadScene("GameStart");
        }
    }

    public void gototitle()
    {
        SceneManager.LoadScene("GameStart");
    }

}
